let nombre='legolas';
let edad=23;

// let concatenacion=nombre+""+ edad;

// const datos= document.getElementById("datos");
// datos.innerHTML=`<h1>Soy el div de datos</h1>
//                 <h2>Mi nombre es ${concatenacion}</h2>
//                 `;

// Ejercicio: Si la edad es mayor que 18 que diga que es mayor de sino que  es menor
// if(edad>=18){
//     datos.innerHTML +=`<h1>Tu nombre es:${nombre} y eres mayor de edad</h1>`;
// }
// else{
//     datos.innerHTML +=`<h1>Eres menor de edad</h1>`;
// }

// For en js

// for(let i=0; i<100;i++){
//     datos.innerHTML+=`<h1>Iteracion</h1>`+i;
// }

// Funciones en Js
function MostrarNombre(nobre,edad){
    let datos=`<h2>Mi nombre es:${nombre}</h2>
                    <h2>Mi edad es:${edad}</h2>`;
    return datos;                
}

function Imprimir(){
    let datos=document.getElementById("datos");
    datos.innerHTML=MostrarNombre(nombre,edad);
}

Imprimir();
// Objetos en js
// Vamos a crear un arreglo
let nombres=['Legolas','Aragon','Gandalf'];

nombres.forEach(function(valores){
    document.write(valores+'<br/>');
})